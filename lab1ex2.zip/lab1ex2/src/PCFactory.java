// Define the package name for this Java class.
package com.journaldev.design.abstractfactory;

// Import necessary classes from other packages.
import com.journaldev.design.model.Computer;
import com.journaldev.design.model.PC;

// Declare a class named PCFactory that implements the ComputerAbstractFactory interface.
public class PCFactory implements ComputerAbstractFactory {

    // Declare private instance variables to store RAM, HDD, and CPU information.
    private String ram;
    private String hdd;
    private String cpu;

    // Constructor for the PCFactory class that takes RAM, HDD, and CPU as parameters and initializes the instance variables.
    public PCFactory(String ram, String hdd, String cpu) {
        this.ram = ram;
        this.hdd = hdd;
        this.cpu = cpu;
    }

    // Implement the createComputer method as required by the ComputerAbstractFactory interface.
    // This method creates and returns a new PC object with the provided RAM, HDD, and CPU information.
    @Override
    public Computer createComputer() {
        return new PC(ram, hdd, cpu);
    }
}
