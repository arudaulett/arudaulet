// Import necessary classes from other packages.
import com.journaldev.design.abstractfactory.PCFactory;
import com.journaldev.design.abstractfactory.ServerFactory;
//import com.journaldev.design.factory.ComputerFactory;
import com.journaldev.design.model.Computer;

public class TestDesignPatterns {
    public static void main(String[] args) {
        // Call the testAbstractFactory method to demonstrate abstract factory pattern.
        testAbstractFactory();
    }

    private static void testAbstractFactory() {
        // Create a Computer object using the abstract factory pattern with a PCFactory.
        Computer pc = ComputerFactory.getComputer(new PCFactory("2 GB", "500 GB", "2.4 GHz"));

        // Create a Computer object using the abstract factory pattern with a ServerFactory.
        Computer server = ComputerFactory.getComputer(new ServerFactory("16 GB", "1 TB", "3.2 GHz"));

        // Print information about the created PC.
        System.out.println("PC Config: " + pc);

        // Print information about the created Server.
        System.out.println("Server Config: " + server);
    }
}
