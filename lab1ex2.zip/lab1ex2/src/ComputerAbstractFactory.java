package com.journaldev.design.abstractfactory; // Package declaration for the abstract factory.

import com.journaldev.design.model.Computer; // Import statement - Import the Computer class from a different package.

// Interface declaration for the ComputerAbstractFactory.
public interface ComputerAbstractFactory {
    // Method to create a Computer object.
    public Computer createComputer();
}
