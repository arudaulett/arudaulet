package com.journaldev.design.model; // Package declaration for the Computer class.

public abstract class Computer {
    // Abstract methods to be implemented by subclasses
    public abstract String getRAM(); // Get the RAM information.
    public abstract String getHDD(); // Get the HDD information.
    public abstract String getCPU(); // Get the CPU information.

    // Override the toString() method to provide a string representation of the object
    @Override
    public String toString() {
        return "RAM= " + this.getRAM() + ", HDD= " + this.getHDD() + ", CPU= " + this.getCPU();
    }
}
