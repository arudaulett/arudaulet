package com.journaldev.design.model; // Package declaration for the PC class.

public class PC extends Computer {
    // Instance variables to store PC configuration
    private String ram;
    private String hdd;
    private String cpu;

    // Constructor for PC class
    public PC(String ram, String hdd, String cpu) {
        this.ram = ram;
        this.hdd = hdd;
        this.cpu = cpu;
    }

    // Implementing abstract methods from the Computer class
    @Override
    public String getRAM() {
        return this.ram;
    }

    @Override
    public String getHDD() {
        return this.hdd;
    }

    @Override
    public String getCPU() {
        return this.cpu;
    }
}
