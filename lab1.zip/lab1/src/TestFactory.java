package com.journaldev.design.test; // Package declaration - This class is in the "com.journaldev.design.test" package.

//import com.journaldev.design.abstractfactory.PCFactory; // Import statement - Import the PCFactory class from a different package.
//import com.journaldev.design.abstractfactory.ServerFactory; // Import statement - Import the ServerFactory class from a different package.
import com.journaldev.design.factory.ComputerFactory; // Import statement - Import the ComputerFactory class from a different package.
import com.journaldev.design.model.Computer; // Import statement - Import the Computer class from a different package.

public class TestFactory {
    public static void main(String[] args) {
        // Create a PC object using the ComputerFactory
        Computer pc = ComputerFactory.getComputer("pc", "2 GB", "500 GB", "2.4 GHz");

        // Create a Server object using the ComputerFactory
        Computer server = ComputerFactory.getComputer("server", "16 GB", "1 TB", "2.9 GHz");

        // Print the PC and Server objects
        System.out.println("PC Configuration: " + pc); // Print PC configuration
        System.out.println("Server Configuration: " + server); // Print Server configuration
    }
}
