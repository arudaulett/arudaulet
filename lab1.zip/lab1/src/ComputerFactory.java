package com.journaldev.design.factory; // Package declaration - This class is in the "com.journaldev.design.factory" package.

import com.journaldev.design.model.Computer; // Import statement - Import the Computer class from a different package.
import com.journaldev.design.model.PC; // Import statement - Import the PC class from a different package.
import com.journaldev.design.model.Server; // Import statement - Import the Server class from a different package.

public class ComputerFactory {

    // Factory Method
    public static Computer getComputer(String type, String ram, String hdd, String cpu) {
        if ("PC".equalsIgnoreCase(type)) {
            return new Computer(ram, hdd, cpu); // Create and return a PC object if the type is "PC".
        } else if ("Server".equalsIgnoreCase(type))
            return new Server(ram, hdd, cpu); // Create and return a Server object if the type is "Server".
        return null; // Return null if the type is not recognized.
    }
}
