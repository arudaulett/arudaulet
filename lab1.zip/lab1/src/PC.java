package com.journaldev.design.model; // This line declares the package in which the PC class is located.

public class PC extends Computer { // This line defines a class named "PC" that extends the "Computer" class.

    private String ram; // This line declares a private instance variable named "ram" of type String.
    private String hdd; // This line declares a private instance variable named "hdd" of type String.
    private String cpu; // This line declares a private instance variable named "cpu" of type String.

    public PC(String ram, String hdd, String cpu) { // This line defines a constructor for the PC class that takes three String parameters.
        this.ram = ram; // This line assigns the value of the "ram" parameter to the "ram" instance variable.
        this.hdd = hdd; // This line assigns the value of the "hdd" parameter to the "hdd" instance variable.
        this.cpu = cpu; // This line assigns the value of the "cpu" parameter to the "cpu" instance variable.
    }

    @Override
    public String getRAM() { // This line defines an overridden method named "getRAM" that returns a String.
        return this.ram; // This line returns the value of the "ram" instance variable.
    }

    @Override
    public String getHDD() { // This line defines an overridden method named "getHDD" that returns a String.
        return this.hdd; // This line returns the value of the "hdd" instance variable.
    }

    @Override
    public String getCPU() { // This line defines an overridden method named "getCPU" that returns a String.
        return this.cpu; // This line returns the value of the "cpu" instance variable.
    }
}
