// Declare the package where the class belongs
package com.journaldev.design.model;

// Define an abstract class named 'Computer'
public abstract class Computer {
    // Declare three abstract methods to get RAM, HDD, and CPU information
    public abstract String getRAM();
    public abstract String getHDD();
    public abstract String getCPU();

    // Override the 'toString()' method to provide a custom string representation
    @Override
    public String toString() {
        // Construct a string representation by calling the abstract methods
        // to get RAM, HDD, and CPU information and formatting it
        return "RAM= " + this.getRAM() + ", HDD=" + this.getHDD() +
                ", CPU=" + this.getCPU();
    }
}
