package com.journaldev.design.model; // Package declaration - This class is in the "com.journaldev.design.model" package.

public class Server extends Computer { // Class declaration - Server class extends the Computer class.

    // Instance Variables
    private String ram; // Variable to store RAM information.
    private String hdd; // Variable to store HDD information.
    private String cpu; // Variable to store CPU information.

    // Constructor
    public Server(String ram, String hdd, String cpu) { // Constructor for the Server class with three parameters.
        this.ram = ram; // Initialize the ram instance variable with the provided value.
        this.hdd = hdd; // Initialize the hdd instance variable with the provided value.
        this.cpu = cpu; // Initialize the cpu instance variable with the provided value.
    }

    // Overridden Methods

    @Override
    public String getRAM() { // Override method to get RAM information.
        return this.ram; // Return the value of the ram instance variable.
    }

    @Override
    public String getHDD() { // Override method to get HDD information.
        return this.hdd; // Return the value of the hdd instance variable.
    }

    @Override
    public String getCPU() { // Override method to get CPU information.
        return this.cpu; // Return the value of the cpu instance variable.
    }
}
