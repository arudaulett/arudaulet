package builder_design_pattern;

// Define a class for creating vehicles
class Vehicle {
    private String engine;
    private int wheel;
    private int airbags;

    public String getEngine() {
        return this.engine;
    }

    public int getWheel() {
        return this.wheel;
    }

    public int getAirbags() {
        return this.airbags;
    }

    // Private constructor to be used by the VehicleBuilder
    private Vehicle(VehicleBuilder builder) {
        this.engine = builder.engine;
        this.wheel = builder.wheel;
        this.airbags = builder.airbags;
    }

    // Define a static inner class for building vehicles
    public static class VehicleBuilder {
        private String engine;
        private int wheel;
        private int airbags;

        // Constructor with required parameters
        public VehicleBuilder(String engine, int wheel) {
            this.engine = engine;
            this.wheel = wheel;
        }

        // Method to set optional parameters
        public VehicleBuilder setAirbags(int airbags) {
            this.airbags = airbags;
            return this;
        }

        // Method to create a new Vehicle using the builder
        public Vehicle build() {
            return new Vehicle(this);
        }
    }
}

public class BuilderPattern {
    public static void main(String[] args) {
        // Create a car with specific engine, wheel, and airbags using the builder
        Vehicle car = new Vehicle.VehicleBuilder("1500cc", 4).setAirbags(4).build();
        // Create a bike with specific engine and wheel (no airbags)
        Vehicle bike = new Vehicle.VehicleBuilder("250cc", 2).build();

        // Print the details of the car and bike
        System.out.println("Car Engine: " + car.getEngine());
        System.out.println("Car Wheel: " + car.getWheel());
        System.out.println("Car Airbags: " + car.getAirbags());
    }
}



