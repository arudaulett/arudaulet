package adapter_design_pattern;

// Define an interface for WebDriver with two methods
interface WebDriver {
    public void getElement();
    public void selectElement();
}

// Create a class ChromeDriver that implements the WebDriver interface
class ChromeDriver implements WebDriver {
    @Override
    public void getElement() {
        System.out.println("Get element from ChromeDriver");
    }

    @Override
    public void selectElement() {
        System.out.println("Select element from ChromeDriver");
    }
}

// Create a class IEDriver with its own methods
class IEDriver {
    public void findElement() {
        System.out.println("Find element from IEDriver");
    }

    public void clickElement() {
        System.out.println("Click element from IEDriver");
    }
}

// Create a class WebDriverAdapter that implements the WebDriver interface
class WebDriverAdapter implements WebDriver {
    IEDriver ieDriver;

    // Constructor to adapt an IEDriver to WebDriver
    public WebDriverAdapter(IEDriver ieDriver) {
        this.ieDriver = ieDriver;
    }

    @Override
    public void getElement() {
        // Adapt the IEDriver's findElement method to WebDriver's getElement
        ieDriver.findElement();
    }

    @Override
    public void selectElement() {
        // Adapt the IEDriver's clickElement method to WebDriver's selectElement
        ieDriver.clickElement();
    }
}

public class AdapterPattern {
    public static void main(String[] args) {
        // Create a ChromeDriver object and demonstrate its methods
        ChromeDriver chromeDriver = new ChromeDriver();
        chromeDriver.getElement();
        chromeDriver.selectElement();

        // Create an IEDriver object and demonstrate its methods
        IEDriver ieDriver = new IEDriver();
        ieDriver.findElement();
        ieDriver.clickElement();

        // Create a WebDriverAdapter to adapt the IEDriver to WebDriver and demonstrate its methods
        WebDriver adaptedDriver = new WebDriverAdapter(ieDriver);
        adaptedDriver.getElement();
        adaptedDriver.selectElement();
    }
}

